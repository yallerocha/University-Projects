package sorting.divideAndConquer;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import sorting.AbstractSorting;

/**
 * Merge sort is based on the divide-and-conquer paradigm. The algorithm
 * consists of recursively dividing the unsorted list in the middle, sorting
 * each sublist, and then merging them into one single sorted list. Notice that
 * if the list has length == 1, it is already sorted.
 */
public class MergeSort<T extends Comparable<T>> extends AbstractSorting<T> {

	@Override
	public void sort(T[] array, int leftIndex, int rightIndex) {
		if(array.length == 1 || array.length == 0) {
			return;
		} else {

			int meio = rightIndex / 2 + 1;
		
			List<T> leftList = new ArrayList<T>();
			List<T> rightList = new ArrayList<T>();
			T[] leftArray = Arrays.copyOfRange(array, leftIndex, meio);
			T[] rightArray = Arrays.copyOfRange(array, meio, rightIndex + 1);
			
			for(T num: leftArray) {
				leftList.add(num);
			}
			for(T num: rightArray) {
				rightList.add(num);
			}
			sort(leftArray, leftIndex, meio);
			sort(rightArray, meio, rightIndex);
			merge(leftList, rightList);
		}
	}
	private List<T> merge(List<T> leftList, List<T> rightList) {
		List<T> result = new ArrayList<T>();
		
		while(leftList.size() > 0 && rightList.size() > 0) {
			if(leftList.get(0).compareTo(rightList.get(0)) <= 0) {
				result.add(leftList.remove(0));
			} else {
				result.add(rightList.remove(0));
			} 
		}
		if(leftList.size() > 0) {
			result.addAll(leftList);
		}
		if(rightList.size() > 0) {
			result.addAll(rightList);
		}
		return result;
		
	}
}
